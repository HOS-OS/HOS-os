#!/bin/bash


searchString="Hos OS 3.2"
 file="/etc/lsb-release"
 if grep -q "$searchString" $file
    then
       clear; echo "Welcome to Hos OS update 3.3 This update will update your system and fix screen brightness issues, and install sweeper. 
which is used to free more storage on your computer.
YON NEED TO HAVE HOS OS 3.2 INSTALLED. 
TO SEE IF YOU DO TYPE lsb_release -dr INTO THE TERMINAL TO SEE WHAT VERSION YOU ARE ON.
Do you wish to install Hos OS update 3.3? after installation, your computer will automatically restart.   "
select yn in "Yes" "No"; do
    case $yn in
Yes )  sudo add-apt-repository ppa:apandada1/brightness-controller;
sudo apt update; sudo apt install -y brightness-controller; sudo apt install -y sweeper; rm -f '/etc/xdg/openbox/menu.xml'; cp '/home/hosos/Hos OS 3.3/menu.xml' '/etc/xdg/openbox/' ;
  cp '/home/hosos/Hos OS 3.3/Hos OS 3.3 wallpapers/hos poly 7.png' '/home/hosos/Hos OS 3.3/Hos OS 3.3 wallpapers/hos poly 6.png' '/home/hosos/Hos OS 3.3/Hos OS 3.3 wallpapers/hos poly 5.png' '/home/hosos/Hos OS 3.3/Hos OS 3.3 wallpapers/hos poly 8.png' /usr/share/backgrounds;  sed -i 's/DISTRIB_DESCRIPTION="Hos OS 3.2"/DISTRIB_DESCRIPTION="Hos OS 3.3"/' /etc/lsb-release ; sed -i 's/PRETTY_NAME="Hos OS 3.2"/PRETTY_NAME="Hos OS 3.3"/' /usr/lib/os-release; clear;

echo "-> finished. your computer will reboot in 10 seconds"; secs=$((1* 10))
while [ $secs -gt 0 ]; do
   echo -ne "$secs\033[0K\r"
   sleep 1
   : $((secs--))
done; sudo reboot;;
 
 No ) exit;;
    esac
done      
            
            
            
    else
            clear; echo "I'm sorry but your computer may be on a older version of Hos OS. To check type in [ lsb_release -dr ] to see the version you are on.
you need to update to Hos OS 3.2 before you can update to Hos OS 3.3. 
go to https://sites.google.com/view/hos-os-download/system-updates to see the last update for Hos OS.  ";
 fi




