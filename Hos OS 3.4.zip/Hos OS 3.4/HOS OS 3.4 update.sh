#!/bin/bash


searchString="Hos OS 3.3"
 file="/etc/lsb-release"
 if grep -q "$searchString" $file
    then
       clear; echo "Welcome to Hos OS update 3.4 
YOU NEED TO HAVE HOS OS 3.3 INSTALLED TO UPDATE! TO SEE IF YOU DO TYPE lsb_release -dr INTO THE TERMINAL TO SEE WHAT VERSION YOU ARE ON.
This update will install new packages for applications for your system and update any application files.
Also neofetch and file-roller will be installed to help with system information and for file unzip and compression.
 Do you wish to install Hos OS update 3.4? after installation, your computer will automatically restart.   "
select yn in "Yes" "No"; do 
    case $yn in
Yes )  sudo apt update; sudo apt install -y neofetch; sudo apt install -y file-roller; sudo apt install -y blueman; sudo apt upgrade; sed -i 's/DISTRIB_DESCRIPTION="Ubuntu 20.04.3 LTS"/DISTRIB_DESCRIPTION="Hos OS 3.3"/' /etc/lsb-release ;sed -i 's/DISTRIB_DESCRIPTION="Hos OS 3.3"/DISTRIB_DESCRIPTION="Hos OS 3.4"/' /etc/lsb-release ;
 sed -i 's/PRETTY_NAME="Ubuntu 20.04.3 LTS"/PRETTY_NAME="Hos OS 3.4"/' /usr/lib/os-release; sed -i 's/NAME="Ubuntu"/NAME="Hos OS"/' /usr/lib/os-release; clear;

echo "-> finished. your computer will reboot in 10 seconds"; secs=$((1* 10))
while [ $secs -gt 0 ]; do
   echo -ne "$secs\033[0K\r"
   sleep 1
   : $((secs--))
done; sudo reboot;;
 
 No ) exit;;
    esac
done      
            
            
            
    else
            clear; echo "I'm sorry but your computer may be on a older version of Hos OS. To check type in [ lsb_release -dr ] to see the version you are on.
you need to update to Hos OS 3.3 before you can update to Hos OS 3.4
go to https://sites.google.com/view/hos-os-download/system-updates to see the last update for Hos OS.  ";
 fi
